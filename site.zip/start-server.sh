python -m SimpleHTTPServer  
